import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Task } from '@/types';
import Colors from '@/constants/Colors';
import Metrics from '@/constants/Metrics';
import { useColorScheme } from 'react-native';
import { Tag } from './Tag';
import { formatDistanceToNow } from '@/utils/dateHelpers';
import { AlarmClock, CircleCheck as CheckCircle } from 'lucide-react-native';

interface TaskCardProps {
  task: Task;
  onPress: (task: Task) => void;
}

export function TaskCard({ task, onPress }: TaskCardProps) {
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'completed';
  const dueText = formatDistanceToNow(new Date(task.dueDate));

  return (
    <TouchableOpacity
      style={[
        styles.container,
        { backgroundColor: colors.card, borderColor: colors.border }
      ]}
      onPress={() => onPress(task)}
      activeOpacity={0.7}
    >
      <View style={styles.header}>
        <Tag type="priority" value={task.priority} />
        <Tag type="status" value={task.status} />
      </View>
      <Text style={[styles.title, { color: colors.text }]}>{task.title}</Text>
      <Text 
        style={[styles.description, { color: colors.text + '99' }]}
        numberOfLines={2}
      >
        {task.description}
      </Text>
      <View style={styles.footer}>
        {isOverdue ? (
          <View style={styles.dueDateContainer}>
            <AlarmClock size={16} color={colors.error} />
            <Text style={[styles.dueDateText, { color: colors.error }]}>
              Overdue by {dueText}
            </Text>
          </View>
        ) : (
          <View style={styles.dueDateContainer}>
            <AlarmClock size={16} color={colors.text + '99'} />
            <Text style={[styles.dueDateText, { color: colors.text + '99' }]}>
              Due {dueText}
            </Text>
          </View>
        )}
        
        {task.status === 'completed' && (
          <View style={styles.completedContainer}>
            <CheckCircle size={16} color={colors.success} />
            <Text style={[styles.completedText, { color: colors.success }]}>
              Completed
            </Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: Metrics.spacing.md,
    borderRadius: Metrics.borderRadius.md,
    borderWidth: 1,
    marginBottom: Metrics.spacing.md,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: Metrics.spacing.sm,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.lg,
    marginBottom: Metrics.spacing.xs,
  },
  description: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
    marginBottom: Metrics.spacing.md,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dueDateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dueDateText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.sm,
    marginLeft: Metrics.spacing.xs,
  },
  completedContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  completedText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.sm,
    marginLeft: Metrics.spacing.xs,
  },
});