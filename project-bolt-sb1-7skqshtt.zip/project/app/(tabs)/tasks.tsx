import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  RefreshControl,
  TouchableOpacity,
  SafeAreaView,
  TextInput
} from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import Metrics from '@/constants/Metrics';
import { TaskCard } from '@/components/TaskCard';
import { Task, TaskStatus } from '@/types';
import { tasks } from '@/data/mockData';
import { useRouter, useLocalSearchParams } from 'expo-router';
import Animated, { FadeIn } from 'react-native-reanimated';
import { Plus, Search, Filter, CircleCheck as CheckCircle, Clock, ListTodo, CircleAlert as AlertCircle } from 'lucide-react-native';
import { Button } from '@/components/Button';

export default function TasksScreen() {
  const params = useLocalSearchParams();
  const initialFilter = params.filter as string || 'all';
  
  const router = useRouter();
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>(initialFilter);
  
  const filteredTasks = tasks.filter((task) => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedStatus === 'all') {
      return matchesSearch;
    } else if (selectedStatus === 'upcoming') {
      const now = new Date();
      const twoDaysFromNow = new Date(now);
      twoDaysFromNow.setHours(now.getHours() + 48);
      const dueDate = new Date(task.dueDate);
      return matchesSearch && dueDate > now && dueDate <= twoDaysFromNow && task.status !== 'completed';
    } else {
      return matchesSearch && task.status === selectedStatus;
    }
  });
  
  const handleTaskPress = (task: Task) => {
    // Navigate to task details
    router.push(`/tasks/${task.id}`);
  };
  
  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    // Simulate loading
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  }, []);
  
  const handleFilterPress = (status: string) => {
    setSelectedStatus(status);
  };
  
  const StatusFilter = ({ title, status, icon }: { title: string, status: string, icon: React.ReactNode }) => (
    <TouchableOpacity
      style={[
        styles.filterButton,
        { 
          backgroundColor: selectedStatus === status ? colors.primary + '20' : 'transparent',
          borderColor: selectedStatus === status ? colors.primary : colors.border
        }
      ]}
      onPress={() => handleFilterPress(status)}
    >
      {icon}
      <Text 
        style={[
          styles.filterText, 
          { 
            color: selectedStatus === status ? colors.primary : colors.text + '80',
            fontFamily: selectedStatus === status ? 'Inter-Medium' : 'Inter-Regular'
          }
        ]}
      >
        {title}
      </Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={styles.container}>
        <View style={styles.headerContainer}>
          <View style={[styles.searchContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Search size={20} color={colors.text + '80'} />
            <TextInput
              style={[styles.searchInput, { color: colors.text }]}
              placeholder="Search tasks..."
              placeholderTextColor={colors.text + '60'}
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
          <TouchableOpacity 
            style={[styles.iconButton, { backgroundColor: colors.primary }]}
            onPress={() => router.push('/tasks/new')}
          >
            <Plus size={24} color="#FFF" />
          </TouchableOpacity>
        </View>
        
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filtersContainer}
        >
          <StatusFilter 
            title="All" 
            status="all" 
            icon={<Filter size={16} color={selectedStatus === 'all' ? colors.primary : colors.text + '80'} />} 
          />
          <StatusFilter 
            title="Todo" 
            status="todo" 
            icon={<ListTodo size={16} color={selectedStatus === 'todo' ? colors.primary : colors.text + '80'} />} 
          />
          <StatusFilter 
            title="In Progress" 
            status="in_progress" 
            icon={<Clock size={16} color={selectedStatus === 'in_progress' ? colors.primary : colors.text + '80'} />} 
          />
          <StatusFilter 
            title="Completed" 
            status="completed" 
            icon={<CheckCircle size={16} color={selectedStatus === 'completed' ? colors.primary : colors.text + '80'} />} 
          />
          <StatusFilter 
            title="Delayed" 
            status="delayed" 
            icon={<AlertCircle size={16} color={selectedStatus === 'delayed' ? colors.primary : colors.text + '80'} />} 
          />
          <StatusFilter 
            title="Upcoming" 
            status="upcoming" 
            icon={<Clock size={16} color={selectedStatus === 'upcoming' ? colors.primary : colors.text + '80'} />} 
          />
        </ScrollView>
        
        <ScrollView
          style={styles.tasksContainer}
          contentContainerStyle={styles.contentContainer}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        >
          <Animated.View entering={FadeIn.duration(400)}>
            {filteredTasks.length > 0 ? (
              filteredTasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onPress={handleTaskPress}
                />
              ))
            ) : (
              <View style={styles.emptyContainer}>
                <Text style={[styles.emptyText, { color: colors.text + '80' }]}>
                  No tasks found
                </Text>
                <Button
                  title="Create New Task"
                  onPress={() => router.push('/tasks/new')}
                  variant="primary"
                  style={{ marginTop: Metrics.spacing.lg }}
                />
              </View>
            )}
          </Animated.View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerContainer: {
    flexDirection: 'row',
    padding: Metrics.spacing.lg,
    alignItems: 'center',
    gap: Metrics.spacing.md,
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: Metrics.borderRadius.md,
    borderWidth: 1,
    paddingHorizontal: Metrics.spacing.md,
    paddingVertical: Metrics.spacing.sm,
  },
  searchInput: {
    flex: 1,
    marginLeft: Metrics.spacing.sm,
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
  },
  iconButton: {
    width: 48,
    height: 48,
    borderRadius: Metrics.borderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  filtersContainer: {
    paddingHorizontal: Metrics.spacing.lg,
    gap: Metrics.spacing.sm,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Metrics.spacing.md,
    paddingVertical: Metrics.spacing.sm,
    borderRadius: Metrics.borderRadius.sm,
    borderWidth: 1,
  },
  filterText: {
    fontSize: Metrics.fontSize.sm,
    marginLeft: Metrics.spacing.xs,
  },
  tasksContainer: {
    flex: 1,
  },
  contentContainer: {
    padding: Metrics.spacing.lg,
    paddingTop: Metrics.spacing.md,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Metrics.spacing.xxl,
  },
  emptyText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.lg,
  },
});