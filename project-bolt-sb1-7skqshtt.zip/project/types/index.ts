export type PriorityLevel = 'low' | 'medium' | 'high' | 'critical';
export type TaskStatus = 'todo' | 'in_progress' | 'completed' | 'delayed';

export interface Department {
  id: string;
  name: string;
  color: string;
  managerId?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  departmentId: string;
  role: 'admin' | 'manager' | 'member';
}

export interface Task {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: PriorityLevel;
  departmentId: string;
  assigneeId?: string;
  creatorId: string;
  createdAt: string;
  updatedAt: string;
  dueDate: string;
  completedAt?: string;
  comments: Comment[];
  attachments: Attachment[];
}

export interface Comment {
  id: string;
  taskId: string;
  userId: string;
  text: string;
  createdAt: string;
}

export interface Attachment {
  id: string;
  taskId: string;
  filename: string;
  url: string;
  uploadedAt: string;
  uploadedBy: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
  type: 'deadline' | 'mention' | 'assignment' | 'update';
  taskId?: string;
}