import { Department, Task, User, Notification } from '@/types';

export const users: User[] = [
  {
    id: '1',
    name: 'John Doe',
    email: 'john@example.com',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
    departmentId: '1',
    role: 'admin'
  },
  {
    id: '2',
    name: 'Jane Smith',
    email: 'jane@example.com',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
    departmentId: '2',
    role: 'manager'
  },
  {
    id: '3',
    name: 'Mark Johnson',
    email: 'mark@example.com',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
    departmentId: '1',
    role: 'member'
  },
  {
    id: '4',
    name: 'Sarah Williams',
    email: 'sarah@example.com',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
    departmentId: '3',
    role: 'manager'
  }
];

export const departments: Department[] = [
  {
    id: '1',
    name: 'Marketing',
    color: '#4CAF50',
    managerId: '2'
  },
  {
    id: '2',
    name: 'Finance',
    color: '#2196F3',
    managerId: '4'
  },
  {
    id: '3',
    name: 'Human Resources',
    color: '#F44336',
    managerId: '3'
  },
  {
    id: '4',
    name: 'Operations',
    color: '#FF9800'
  }
];

// Create tasks with different statuses and due dates
const createTasks = (): Task[] => {
  const now = new Date();
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  
  const tomorrow = new Date(now);
  tomorrow.setDate(now.getDate() + 1);
  
  const nextWeek = new Date(now);
  nextWeek.setDate(now.getDate() + 7);
  
  return [
    {
      id: '1',
      title: 'Complete quarterly financial report',
      description: 'Prepare and submit the Q2 financial report with all department expenditures and revenue forecasts',
      status: 'in_progress',
      priority: 'high',
      departmentId: '2',
      assigneeId: '2',
      creatorId: '1',
      createdAt: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: now.toISOString(),
      dueDate: tomorrow.toISOString(),
      comments: [],
      attachments: []
    },
    {
      id: '2',
      title: 'Create marketing campaign for product launch',
      description: 'Design and implement marketing strategy for new product line including social media, email, and PPC campaigns',
      status: 'todo',
      priority: 'critical',
      departmentId: '1',
      assigneeId: '3',
      creatorId: '1',
      createdAt: new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: now.toISOString(),
      dueDate: nextWeek.toISOString(),
      comments: [],
      attachments: []
    },
    {
      id: '3',
      title: 'Conduct employee satisfaction survey',
      description: 'Create, distribute, and analyze results from the annual employee satisfaction survey',
      status: 'completed',
      priority: 'medium',
      departmentId: '3',
      assigneeId: '4',
      creatorId: '1',
      createdAt: new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      dueDate: yesterday.toISOString(),
      completedAt: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      comments: [],
      attachments: []
    },
    {
      id: '4',
      title: 'Update employee handbook',
      description: 'Review and update the employee handbook with new policies and procedures',
      status: 'delayed',
      priority: 'medium',
      departmentId: '3',
      assigneeId: '4',
      creatorId: '2',
      createdAt: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: now.toISOString(),
      dueDate: yesterday.toISOString(),
      comments: [],
      attachments: []
    },
    {
      id: '5',
      title: 'Optimize supply chain logistics',
      description: 'Analyze current supply chain processes and identify opportunities for optimization',
      status: 'in_progress',
      priority: 'high',
      departmentId: '4',
      creatorId: '1',
      createdAt: new Date(now.getTime() - 10 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: now.toISOString(),
      dueDate: nextWeek.toISOString(),
      comments: [],
      attachments: []
    },
    {
      id: '6',
      title: 'Prepare monthly budget report',
      description: 'Compile and analyze departmental spending against budget allocations',
      status: 'todo',
      priority: 'high',
      departmentId: '2',
      assigneeId: '2',
      creatorId: '1',
      createdAt: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: now.toISOString(),
      dueDate: tomorrow.toISOString(),
      comments: [],
      attachments: []
    },
    {
      id: '7',
      title: 'Schedule interviews for developer position',
      description: 'Coordinate with candidates and team members to schedule interviews for the senior developer role',
      status: 'completed',
      priority: 'medium',
      departmentId: '3',
      assigneeId: '4',
      creatorId: '1',
      createdAt: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      dueDate: yesterday.toISOString(),
      completedAt: new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      comments: [],
      attachments: []
    },
    {
      id: '8',
      title: 'Update website content',
      description: 'Review and refresh content on the company website to reflect new products and services',
      status: 'delayed',
      priority: 'low',
      departmentId: '1',
      assigneeId: '3',
      creatorId: '2',
      createdAt: new Date(now.getTime() - 15 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: now.toISOString(),
      dueDate: yesterday.toISOString(),
      comments: [],
      attachments: []
    }
  ];
};

export const tasks: Task[] = createTasks();

export const notifications: Notification[] = [
  {
    id: '1',
    userId: '1',
    title: 'Task deadline approaching',
    message: 'The task "Complete quarterly financial report" is due tomorrow',
    isRead: false,
    createdAt: new Date().toISOString(),
    type: 'deadline',
    taskId: '1'
  },
  {
    id: '2',
    userId: '1',
    title: 'New task assigned',
    message: 'You have been assigned to "Create marketing campaign for product launch"',
    isRead: true,
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    type: 'assignment',
    taskId: '2'
  },
  {
    id: '3',
    userId: '1',
    title: 'Task completed',
    message: 'The task "Conduct employee satisfaction survey" has been completed',
    isRead: false,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    type: 'update',
    taskId: '3'
  }
];

export const getTaskStats = () => {
  const todoCount = tasks.filter(task => task.status === 'todo').length;
  const inProgressCount = tasks.filter(task => task.status === 'in_progress').length;
  const completedCount = tasks.filter(task => task.status === 'completed').length;
  const delayedCount = tasks.filter(task => task.status === 'delayed').length;
  
  return { todoCount, inProgressCount, completedCount, delayedCount };
};

export const getTasksByStatus = (status: string) => {
  return tasks.filter(task => task.status === status);
};

export const getTasksByDepartment = (departmentId: string) => {
  return tasks.filter(task => task.departmentId === departmentId);
};

export const getTasksByAssignee = (assigneeId: string) => {
  return tasks.filter(task => task.assigneeId === assigneeId);
};

export const getUserById = (id: string) => {
  return users.find(user => user.id === id);
};

export const getDepartmentById = (id: string) => {
  return departments.find(department => department.id === id);
};