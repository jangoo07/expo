import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Colors from '@/constants/Colors';
import Metrics from '@/constants/Metrics';
import { useColorScheme } from 'react-native';
import { CircleCheck as CheckCircle, Clock, CircleAlert as AlertCircle, ListTodo } from 'lucide-react-native';
import Animated, { FadeInUp } from 'react-native-reanimated';

interface StatusCardProps {
  title: string;
  count: number;
  type: 'todo' | 'in_progress' | 'completed' | 'delayed';
  index: number;
}

export function StatusCard({ title, count, type, index }: StatusCardProps) {
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const getIcon = () => {
    switch (type) {
      case 'todo':
        return <ListTodo size={24} color="#FFF" />;
      case 'in_progress':
        return <Clock size={24} color="#FFF" />;
      case 'completed':
        return <CheckCircle size={24} color="#FFF" />;
      case 'delayed':
        return <AlertCircle size={24} color="#FFF" />;
      default:
        return null;
    }
  };
  
  const getColor = () => {
    switch (type) {
      case 'todo':
        return colors.primary;
      case 'in_progress':
        return colors.warning;
      case 'completed':
        return colors.success;
      case 'delayed':
        return colors.error;
      default:
        return colors.primary;
    }
  };

  return (
    <Animated.View
      entering={FadeInUp.delay(index * 100).duration(400)}
      style={[
        styles.container,
        { backgroundColor: colors.card, borderColor: colors.border }
      ]}
    >
      <View style={[styles.iconContainer, { backgroundColor: getColor() }]}>
        {getIcon()}
      </View>
      <View style={styles.textContainer}>
        <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
        <Text style={[styles.count, { color: getColor() }]}>{count}</Text>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    padding: Metrics.spacing.md,
    borderRadius: Metrics.borderRadius.md,
    borderWidth: 1,
    marginBottom: Metrics.spacing.md,
    alignItems: 'center',
    flex: 1,
    minWidth: '48%',
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: Metrics.borderRadius.sm,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: Metrics.spacing.md,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.sm,
    marginBottom: Metrics.spacing.xs,
  },
  count: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.xl,
  },
});