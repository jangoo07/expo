import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView,
  TouchableOpacity,
  TextInput,
  SafeAreaView
} from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import Metrics from '@/constants/Metrics';
import { Task, PriorityLevel, TaskStatus } from '@/types';
import { tasks, departments, getUserById, getDepartmentById } from '@/data/mockData';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { ArrowLeft, Calendar, User, Building, CreditCard as Edit2, Trash2, MessageSquare, Send, Clock, CircleCheck as CheckCircle, TriangleAlert as AlertTriangle, ListTodo } from 'lucide-react-native';
import { Tag } from '@/components/Tag';
import { formatDate, isOverdue } from '@/utils/dateHelpers';
import { Button } from '@/components/Button';

export default function TaskDetailsScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const task = tasks.find(t => t.id === id) as Task;
  
  const [comment, setComment] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editedTask, setEditedTask] = useState<Partial<Task>>({});
  
  if (!task) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
        <View style={[styles.container, { alignItems: 'center', justifyContent: 'center' }]}>
          <Text style={[styles.errorText, { color: colors.text }]}>Task not found</Text>
          <Button
            title="Go Back"
            onPress={() => router.back()}
            variant="primary"
            style={{ marginTop: Metrics.spacing.md }}
          />
        </View>
      </SafeAreaView>
    );
  }
  
  const assignee = task.assigneeId ? getUserById(task.assigneeId) : null;
  const department = getDepartmentById(task.departmentId);
  const creator = getUserById(task.creatorId);
  
  const handleStatusChange = (status: TaskStatus) => {
    // In a real app, this would update the task in the database
    console.log(`Changing status to ${status}`);
  };
  
  const handleDelete = () => {
    // In a real app, this would delete the task
    router.back();
  };
  
  const handleEdit = () => {
    setIsEditing(true);
    setEditedTask({
      title: task.title,
      description: task.description,
      priority: task.priority,
    });
  };
  
  const handleSaveEdit = () => {
    // In a real app, this would update the task in the database
    console.log('Saving changes:', editedTask);
    setIsEditing(false);
  };
  
  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedTask({});
  };
  
  const handleAddComment = () => {
    if (comment.trim()) {
      // In a real app, this would add a comment to the task
      console.log('Adding comment:', comment);
      setComment('');
    }
  };
  
  const getStatusIcon = (status: TaskStatus) => {
    switch (status) {
      case 'todo':
        return <ListTodo size={20} color={colors.primary} />;
      case 'in_progress':
        return <Clock size={20} color={colors.warning} />;
      case 'completed':
        return <CheckCircle size={20} color={colors.success} />;
      case 'delayed':
        return <AlertTriangle size={20} color={colors.error} />;
      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <Stack.Screen 
        options={{
          headerShown: true,
          headerTitle: isEditing ? 'Edit Task' : 'Task Details',
          headerLeft: () => (
            <TouchableOpacity onPress={() => router.back()}>
              <ArrowLeft size={24} color={colors.text} />
            </TouchableOpacity>
          ),
          headerRight: () => (
            !isEditing ? (
              <View style={styles.headerActionsContainer}>
                <TouchableOpacity 
                  style={styles.iconButton}
                  onPress={handleEdit}
                >
                  <Edit2 size={20} color={colors.primary} />
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.iconButton}
                  onPress={handleDelete}
                >
                  <Trash2 size={20} color={colors.error} />
                </TouchableOpacity>
              </View>
            ) : null
          ),
        }}
      />
      
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.contentContainer}
      >
        {isEditing ? (
          <View style={styles.editForm}>
            <View style={styles.formGroup}>
              <Text style={[styles.label, { color: colors.text }]}>Title</Text>
              <TextInput
                style={[
                  styles.input,
                  { 
                    backgroundColor: colors.card, 
                    borderColor: colors.border,
                    color: colors.text
                  }
                ]}
                value={editedTask.title}
                onChangeText={(text) => setEditedTask({ ...editedTask, title: text })}
                placeholder="Task title"
                placeholderTextColor={colors.text + '60'}
              />
            </View>
            
            <View style={styles.formGroup}>
              <Text style={[styles.label, { color: colors.text }]}>Description</Text>
              <TextInput
                style={[
                  styles.textArea,
                  { 
                    backgroundColor: colors.card, 
                    borderColor: colors.border,
                    color: colors.text
                  }
                ]}
                value={editedTask.description}
                onChangeText={(text) => setEditedTask({ ...editedTask, description: text })}
                placeholder="Task description"
                placeholderTextColor={colors.text + '60'}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
              />
            </View>
            
            <View style={styles.formGroup}>
              <Text style={[styles.label, { color: colors.text }]}>Priority</Text>
              <View style={styles.priorityOptions}>
                {(['low', 'medium', 'high', 'critical'] as PriorityLevel[]).map((priority) => (
                  <TouchableOpacity
                    key={priority}
                    style={[
                      styles.priorityButton,
                      { 
                        backgroundColor: 
                          editedTask.priority === priority 
                            ? colors.primary
                            : colors.card,
                        borderColor: colors.border
                      }
                    ]}
                    onPress={() => setEditedTask({ ...editedTask, priority })}
                  >
                    <Text 
                      style={[
                        styles.priorityButtonText, 
                        { 
                          color: editedTask.priority === priority 
                            ? '#FFF' 
                            : colors.text 
                        }
                      ]}
                    >
                      {priority.charAt(0).toUpperCase() + priority.slice(1)}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            
            <View style={styles.formActions}>
              <Button
                title="Cancel"
                onPress={handleCancelEdit}
                variant="outline"
                style={{ flex: 1, marginRight: Metrics.spacing.md }}
              />
              <Button
                title="Save Changes"
                onPress={handleSaveEdit}
                variant="primary"
                style={{ flex: 1 }}
              />
            </View>
          </View>
        ) : (
          <>
            <View style={styles.header}>
              <Text style={[styles.taskTitle, { color: colors.text }]}>{task.title}</Text>
              
              <View style={styles.tagsContainer}>
                <Tag type="priority" value={task.priority} />
                <Tag type="status" value={task.status} />
              </View>
            </View>
            
            <Text style={[styles.description, { color: colors.text + '99' }]}>
              {task.description}
            </Text>
            
            <View style={styles.detailsContainer}>
              <View style={[styles.detailItem, { borderBottomColor: colors.border }]}>
                <View style={styles.detailLabel}>
                  <Calendar size={20} color={colors.primary} />
                  <Text style={[styles.detailLabelText, { color: colors.text }]}>
                    Due Date
                  </Text>
                </View>
                <Text 
                  style={[
                    styles.detailValue, 
                    { 
                      color: isOverdue(task.dueDate, task.status) 
                        ? colors.error 
                        : colors.text 
                    }
                  ]}
                >
                  {formatDate(new Date(task.dueDate))}
                  {isOverdue(task.dueDate, task.status) && ' (Overdue)'}
                </Text>
              </View>
              
              <View style={[styles.detailItem, { borderBottomColor: colors.border }]}>
                <View style={styles.detailLabel}>
                  <User size={20} color={colors.primary} />
                  <Text style={[styles.detailLabelText, { color: colors.text }]}>
                    Assignee
                  </Text>
                </View>
                <Text style={[styles.detailValue, { color: colors.text }]}>
                  {assignee ? assignee.name : 'Unassigned'}
                </Text>
              </View>
              
              <View style={[styles.detailItem, { borderBottomColor: colors.border }]}>
                <View style={styles.detailLabel}>
                  <Building size={20} color={colors.primary} />
                  <Text style={[styles.detailLabelText, { color: colors.text }]}>
                    Department
                  </Text>
                </View>
                <Tag 
                  type="department" 
                  value={department?.name || ''} 
                  color={department?.color}
                />
              </View>
              
              <View style={[styles.detailItem, { borderBottomColor: colors.border }]}>
                <View style={styles.detailLabel}>
                  <User size={20} color={colors.primary} />
                  <Text style={[styles.detailLabelText, { color: colors.text }]}>
                    Created By
                  </Text>
                </View>
                <Text style={[styles.detailValue, { color: colors.text }]}>
                  {creator?.name || 'Unknown'}
                </Text>
              </View>
              
              <View style={styles.detailItem}>
                <View style={styles.detailLabel}>
                  <Calendar size={20} color={colors.primary} />
                  <Text style={[styles.detailLabelText, { color: colors.text }]}>
                    Created On
                  </Text>
                </View>
                <Text style={[styles.detailValue, { color: colors.text }]}>
                  {formatDate(new Date(task.createdAt))}
                </Text>
              </View>
            </View>
            
            {task.status !== 'completed' && (
              <View style={styles.actionsContainer}>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>
                  Update Status
                </Text>
                <View style={styles.statusButtons}>
                  <TouchableOpacity
                    style={[
                      styles.statusButton,
                      { 
                        backgroundColor: colors.card, 
                        borderColor: colors.primary,
                      }
                    ]}
                    onPress={() => handleStatusChange('todo')}
                  >
                    <ListTodo size={20} color={colors.primary} />
                    <Text style={[styles.statusButtonText, { color: colors.text }]}>
                      To Do
                    </Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    style={[
                      styles.statusButton,
                      { 
                        backgroundColor: colors.card, 
                        borderColor: colors.warning,
                      }
                    ]}
                    onPress={() => handleStatusChange('in_progress')}
                  >
                    <Clock size={20} color={colors.warning} />
                    <Text style={[styles.statusButtonText, { color: colors.text }]}>
                      In Progress
                    </Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    style={[
                      styles.statusButton,
                      { 
                        backgroundColor: colors.card, 
                        borderColor: colors.success,
                      }
                    ]}
                    onPress={() => handleStatusChange('completed')}
                  >
                    <CheckCircle size={20} color={colors.success} />
                    <Text style={[styles.statusButtonText, { color: colors.text }]}>
                      Complete
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
            
            <View style={styles.commentsContainer}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>
                Comments
              </Text>
              
              {task.comments.length > 0 ? (
                task.comments.map(comment => (
                  <View 
                    key={comment.id}
                    style={[styles.commentItem, { backgroundColor: colors.card, borderColor: colors.border }]}
                  >
                    <Text style={[styles.commentUser, { color: colors.text }]}>
                      {getUserById(comment.userId)?.name || 'Unknown'}
                    </Text>
                    <Text style={[styles.commentText, { color: colors.text + '99' }]}>
                      {comment.text}
                    </Text>
                    <Text style={[styles.commentDate, { color: colors.text + '80' }]}>
                      {formatDate(new Date(comment.createdAt))}
                    </Text>
                  </View>
                ))
              ) : (
                <Text style={[styles.noCommentsText, { color: colors.text + '80' }]}>
                  No comments yet
                </Text>
              )}
              
              <View style={styles.addCommentContainer}>
                <TextInput
                  style={[
                    styles.commentInput,
                    { 
                      backgroundColor: colors.card, 
                      borderColor: colors.border,
                      color: colors.text
                    }
                  ]}
                  value={comment}
                  onChangeText={setComment}
                  placeholder="Add a comment..."
                  placeholderTextColor={colors.text + '60'}
                  multiline
                />
                <TouchableOpacity
                  style={[styles.sendButton, { backgroundColor: colors.primary }]}
                  onPress={handleAddComment}
                  disabled={!comment.trim()}
                >
                  <Send size={20} color="#FFF" />
                </TouchableOpacity>
              </View>
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: Metrics.spacing.lg,
  },
  headerActionsContainer: {
    flexDirection: 'row',
  },
  iconButton: {
    paddingHorizontal: Metrics.spacing.sm,
  },
  header: {
    marginBottom: Metrics.spacing.lg,
  },
  taskTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.xxl,
    marginBottom: Metrics.spacing.md,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Metrics.spacing.sm,
  },
  description: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
    lineHeight: Metrics.fontSize.md * 1.5,
    marginBottom: Metrics.spacing.xl,
  },
  detailsContainer: {
    marginBottom: Metrics.spacing.xl,
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Metrics.spacing.md,
    borderBottomWidth: 1,
  },
  detailLabel: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  detailLabelText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.md,
    marginLeft: Metrics.spacing.sm,
  },
  detailValue: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
  },
  actionsContainer: {
    marginBottom: Metrics.spacing.xl,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.lg,
    marginBottom: Metrics.spacing.md,
  },
  statusButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statusButton: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Metrics.spacing.md,
    borderWidth: 1,
    borderRadius: Metrics.borderRadius.md,
    marginHorizontal: Metrics.spacing.xs,
  },
  statusButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.sm,
    marginTop: Metrics.spacing.xs,
  },
  commentsContainer: {
    marginBottom: Metrics.spacing.xl,
  },
  noCommentsText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
    marginBottom: Metrics.spacing.lg,
    fontStyle: 'italic',
  },
  commentItem: {
    padding: Metrics.spacing.md,
    borderRadius: Metrics.borderRadius.md,
    borderWidth: 1,
    marginBottom: Metrics.spacing.md,
  },
  commentUser: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.md,
    marginBottom: Metrics.spacing.xs,
  },
  commentText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
    marginBottom: Metrics.spacing.sm,
  },
  commentDate: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.xs,
    alignSelf: 'flex-end',
  },
  addCommentContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  commentInput: {
    flex: 1,
    borderWidth: 1,
    borderRadius: Metrics.borderRadius.md,
    paddingHorizontal: Metrics.spacing.md,
    paddingVertical: Metrics.spacing.sm,
    marginRight: Metrics.spacing.sm,
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
    maxHeight: 100,
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: Metrics.borderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.lg,
  },
  editForm: {
    marginBottom: Metrics.spacing.xl,
  },
  formGroup: {
    marginBottom: Metrics.spacing.lg,
  },
  label: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.md,
    marginBottom: Metrics.spacing.sm,
  },
  input: {
    borderWidth: 1,
    borderRadius: Metrics.borderRadius.md,
    paddingHorizontal: Metrics.spacing.md,
    paddingVertical: Metrics.spacing.sm,
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
  },
  textArea: {
    borderWidth: 1,
    borderRadius: Metrics.borderRadius.md,
    paddingHorizontal: Metrics.spacing.md,
    paddingVertical: Metrics.spacing.sm,
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
    minHeight: 100,
  },
  priorityOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  priorityButton: {
    flex: 1,
    paddingVertical: Metrics.spacing.sm,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: Metrics.borderRadius.sm,
    marginHorizontal: 2,
  },
  priorityButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.sm,
  },
  formActions: {
    flexDirection: 'row',
    marginTop: Metrics.spacing.lg,
  },
});