const tintColorLight = '#0066CC';
const tintColorDark = '#4D9FFF';

export default {
  light: {
    primary: '#0066CC',
    secondary: '#00A3A3',
    accent: '#FF9500',
    success: '#34C759',
    warning: '#FFCC00',
    error: '#FF3B30',
    text: '#1C1C1E',
    background: '#F2F2F7',
    card: '#FFFFFF',
    border: '#E5E5EA',
    notification: '#FF3B30',
    tint: tintColorLight,
    tabIconDefault: '#C7C7CC',
    tabIconSelected: tintColorLight,
  },
  dark: {
    primary: '#4D9FFF',
    secondary: '#47C1C1',
    accent: '#FFB340',
    success: '#30D158',
    warning: '#FFD60A',
    error: '#FF453A',
    text: '#FFFFFF',
    background: '#1C1C1E',
    card: '#2C2C2E',
    border: '#38383A',
    notification: '#FF453A',
    tint: tintColorDark,
    tabIconDefault: '#8E8E93',
    tabIconSelected: tintColorDark,
  },
};