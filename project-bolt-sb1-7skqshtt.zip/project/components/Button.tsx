import React from 'react';
import { 
  TouchableOpacity, 
  Text, 
  StyleSheet, 
  ActivityIndicator, 
  ViewStyle,
  TextStyle 
} from 'react-native';
import Colors from '@/constants/Colors';
import Metrics from '@/constants/Metrics';
import { useColorScheme } from 'react-native';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'small' | 'medium' | 'large';
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
  icon?: React.ReactNode;
}

export function Button({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  disabled = false,
  loading = false,
  style,
  textStyle,
  icon
}: ButtonProps) {
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const getBackgroundColor = () => {
    if (disabled) return colors.border;
    
    switch (variant) {
      case 'primary': return colors.primary;
      case 'secondary': return colors.secondary;
      case 'outline': return 'transparent';
      case 'ghost': return 'transparent';
      default: return colors.primary;
    }
  };
  
  const getBorderColor = () => {
    if (disabled) return colors.border;
    
    switch (variant) {
      case 'outline': return colors.primary;
      default: return 'transparent';
    }
  };
  
  const getTextColor = () => {
    if (disabled) return colors.text + '80';
    
    switch (variant) {
      case 'primary': return '#FFF';
      case 'secondary': return '#FFF';
      case 'outline': return colors.primary;
      case 'ghost': return colors.primary;
      default: return '#FFF';
    }
  };
  
  const getPadding = () => {
    switch (size) {
      case 'small': return { paddingVertical: Metrics.spacing.xs, paddingHorizontal: Metrics.spacing.md };
      case 'medium': return { paddingVertical: Metrics.spacing.sm, paddingHorizontal: Metrics.spacing.lg };
      case 'large': return { paddingVertical: Metrics.spacing.md, paddingHorizontal: Metrics.spacing.xl };
      default: return { paddingVertical: Metrics.spacing.sm, paddingHorizontal: Metrics.spacing.lg };
    }
  };
  
  const getFontSize = () => {
    switch (size) {
      case 'small': return Metrics.fontSize.sm;
      case 'medium': return Metrics.fontSize.md;
      case 'large': return Metrics.fontSize.lg;
      default: return Metrics.fontSize.md;
    }
  };

  return (
    <TouchableOpacity
      style={[
        styles.button,
        { 
          backgroundColor: getBackgroundColor(),
          borderColor: getBorderColor(),
          borderWidth: variant === 'outline' ? 1 : 0,
        },
        getPadding(),
        style
      ]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.7}
    >
      {loading ? (
        <ActivityIndicator size="small" color={getTextColor()} />
      ) : (
        <>
          {icon && <View style={styles.iconContainer}>{icon}</View>}
          <Text
            style={[
              styles.text,
              { 
                color: getTextColor(),
                fontSize: getFontSize(),
              },
              textStyle
            ]}
          >
            {title}
          </Text>
        </>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: Metrics.borderRadius.md,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontFamily: 'Inter-Medium',
    textAlign: 'center',
  },
  iconContainer: {
    marginRight: Metrics.spacing.xs,
  },
});