import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  SafeAreaView,
  useWindowDimensions
} from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import Metrics from '@/constants/Metrics';
import { getTaskStats, tasks, departments } from '@/data/mockData';
import Animated, { FadeIn, FadeInRight } from 'react-native-reanimated';
import { ChartPie as PieChart, ChartBarBig as BarChartBig, Calendar } from 'lucide-react-native';

export default function ReportsScreen() {
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  const [selectedTab, setSelectedTab] = useState('overview');
  const { width } = useWindowDimensions();
  
  const { todoCount, inProgressCount, completedCount, delayedCount } = getTaskStats();
  const totalTasks = todoCount + inProgressCount + completedCount + delayedCount;
  
  // Department statistics
  const departmentStats = departments.map(department => {
    const departmentTasks = tasks.filter(task => task.departmentId === department.id);
    const completedTasks = departmentTasks.filter(task => task.status === 'completed').length;
    const totalDeptTasks = departmentTasks.length;
    const completionRate = totalDeptTasks > 0 ? (completedTasks / totalDeptTasks) * 100 : 0;
    
    return {
      id: department.id,
      name: department.name,
      color: department.color,
      taskCount: totalDeptTasks,
      completedCount: completedTasks,
      completionRate: Math.round(completionRate),
    };
  }).sort((a, b) => b.taskCount - a.taskCount);
  
  // Priority statistics
  const priorityStats = {
    low: tasks.filter(task => task.priority === 'low').length,
    medium: tasks.filter(task => task.priority === 'medium').length,
    high: tasks.filter(task => task.priority === 'high').length,
    critical: tasks.filter(task => task.priority === 'critical').length,
  };
  
  const renderStatusPieChart = () => {
    const chartSize = width * 0.8;
    const centerX = chartSize / 2;
    const centerY = chartSize / 2;
    const radius = chartSize * 0.4;
    
    const total = todoCount + inProgressCount + completedCount + delayedCount;
    
    if (total === 0) return (
      <View style={[styles.pieChartContainer, { width: chartSize, height: chartSize }]}>
        <Text style={[styles.emptyChartText, { color: colors.text }]}>No tasks</Text>
      </View>
    );
    
    const slices = [
      { value: todoCount, color: colors.primary, label: 'Todo' },
      { value: inProgressCount, color: colors.warning, label: 'In Progress' },
      { value: completedCount, color: colors.success, label: 'Completed' },
      { value: delayedCount, color: colors.error, label: 'Delayed' },
    ].filter(slice => slice.value > 0);
    
    let startAngle = 0;
    
    return (
      <View style={styles.pieChartContainer}>
        <View style={{ width: chartSize, height: chartSize }}>
          <View style={styles.legendContainer}>
            {slices.map((slice, index) => (
              <View key={index} style={styles.legendItem}>
                <View style={[styles.legendColor, { backgroundColor: slice.color }]} />
                <Text style={[styles.legendText, { color: colors.text }]}>
                  {slice.label} ({slice.value})
                </Text>
              </View>
            ))}
          </View>
          
          <View style={styles.pieChartCenter}>
            <Text style={[styles.totalTasks, { color: colors.text }]}>{total}</Text>
            <Text style={[styles.totalTasksLabel, { color: colors.text + '80' }]}>Total Tasks</Text>
          </View>
          
          <View style={styles.segmentsContainer}>
            {slices.map((slice, index) => {
              const angle = (slice.value / total) * 360;
              const endAngle = startAngle + angle;
              
              // Skip rendering if the slice is too small
              if (angle < 1) return null;
              
              const segment = (
                <View 
                  key={index}
                  style={[
                    styles.segment,
                    {
                      backgroundColor: slice.color,
                      width: radius,
                      height: radius,
                      borderTopRightRadius: index === 0 ? radius : 0,
                      borderBottomRightRadius: index === 2 ? radius : 0,
                      borderTopLeftRadius: index === 1 ? radius : 0,
                      borderBottomLeftRadius: index === 3 ? radius : 0,
                      transform: [
                        { translateX: index % 2 === 0 ? 0 : -radius },
                        { translateY: index < 2 ? 0 : -radius },
                      ],
                    }
                  ]}
                />
              );
              
              startAngle = endAngle;
              return segment;
            })}
          </View>
        </View>
      </View>
    );
  };
  
  const renderDepartmentStats = () => {
    return (
      <View style={styles.departmentStatsContainer}>
        {departmentStats.map((dept, index) => (
          <Animated.View 
            key={dept.id}
            entering={FadeInRight.delay(index * 100).duration(400)}
            style={[styles.departmentCard, { backgroundColor: colors.card, borderColor: colors.border }]}
          >
            <View style={styles.departmentHeader}>
              <View style={[styles.departmentColorIndicator, { backgroundColor: dept.color }]} />
              <Text style={[styles.departmentName, { color: colors.text }]}>{dept.name}</Text>
            </View>
            <Text style={[styles.taskCountText, { color: colors.text + '80' }]}>
              {dept.taskCount} tasks ({dept.completedCount} completed)
            </Text>
            <View style={styles.progressBarContainer}>
              <View 
                style={[
                  styles.progressBar, 
                  { 
                    backgroundColor: colors.border,
                    width: '100%'
                  }
                ]}
              >
                <View 
                  style={[
                    styles.progressBarFill, 
                    { 
                      backgroundColor: dept.color,
                      width: `${dept.completionRate}%`
                    }
                  ]}
                />
              </View>
              <Text style={[styles.progressText, { color: colors.text }]}>
                {dept.completionRate}% complete
              </Text>
            </View>
          </Animated.View>
        ))}
      </View>
    );
  };
  
  const renderPriorityStats = () => {
    const totalPriorities = priorityStats.low + priorityStats.medium + priorityStats.high + priorityStats.critical;
    
    if (totalPriorities === 0) {
      return (
        <View style={styles.emptyContainer}>
          <Text style={[styles.emptyText, { color: colors.text + '80' }]}>
            No tasks available
          </Text>
        </View>
      );
    }
    
    const getPriorityBarWidth = (count: number) => {
      return totalPriorities > 0 ? (count / totalPriorities) * 100 : 0;
    };
    
    return (
      <View style={styles.priorityContainer}>
        <PriorityBar 
          label="Critical" 
          count={priorityStats.critical} 
          color={colors.error} 
          width={getPriorityBarWidth(priorityStats.critical)} 
          textColor={colors.text}
        />
        <PriorityBar 
          label="High" 
          count={priorityStats.high} 
          color={colors.accent} 
          width={getPriorityBarWidth(priorityStats.high)} 
          textColor={colors.text}
        />
        <PriorityBar 
          label="Medium" 
          count={priorityStats.medium} 
          color={colors.warning} 
          width={getPriorityBarWidth(priorityStats.medium)} 
          textColor={colors.text}
        />
        <PriorityBar 
          label="Low" 
          count={priorityStats.low} 
          color={colors.success} 
          width={getPriorityBarWidth(priorityStats.low)} 
          textColor={colors.text}
        />
      </View>
    );
  };
  
  const PriorityBar = ({ label, count, color, width, textColor }: { label: string, count: number, color: string, width: number, textColor: string }) => (
    <Animated.View 
      entering={FadeInRight.duration(400)}
      style={styles.priorityBarContainer}
    >
      <View style={styles.priorityLabelContainer}>
        <View style={[styles.priorityIndicator, { backgroundColor: color }]} />
        <Text style={[styles.priorityLabel, { color: textColor }]}>{label}</Text>
      </View>
      <View style={styles.priorityBarWrapper}>
        <View 
          style={[
            styles.priorityBarBackground, 
            { backgroundColor: color + '30' }
          ]}
        >
          <View 
            style={[
              styles.priorityBarFill, 
              { 
                backgroundColor: color,
                width: `${width}%`
              }
            ]}
          />
        </View>
      </View>
      <Text style={[styles.priorityCount, { color: textColor }]}>{count}</Text>
    </Animated.View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={styles.container}>
        <View style={styles.tabsContainer}>
          <TouchableOpacity
            style={[
              styles.tabButton,
              selectedTab === 'overview' && [styles.activeTabButton, { borderColor: colors.primary }]
            ]}
            onPress={() => setSelectedTab('overview')}
          >
            <PieChart size={20} color={selectedTab === 'overview' ? colors.primary : colors.text + '80'} />
            <Text 
              style={[
                styles.tabButtonText, 
                { color: selectedTab === 'overview' ? colors.primary : colors.text + '80' }
              ]}
            >
              Overview
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.tabButton,
              selectedTab === 'departments' && [styles.activeTabButton, { borderColor: colors.primary }]
            ]}
            onPress={() => setSelectedTab('departments')}
          >
            <BarChartBig size={20} color={selectedTab === 'departments' ? colors.primary : colors.text + '80'} />
            <Text 
              style={[
                styles.tabButtonText, 
                { color: selectedTab === 'departments' ? colors.primary : colors.text + '80' }
              ]}
            >
              By Department
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.tabButton,
              selectedTab === 'priority' && [styles.activeTabButton, { borderColor: colors.primary }]
            ]}
            onPress={() => setSelectedTab('priority')}
          >
            <Calendar size={20} color={selectedTab === 'priority' ? colors.primary : colors.text + '80'} />
            <Text 
              style={[
                styles.tabButtonText, 
                { color: selectedTab === 'priority' ? colors.primary : colors.text + '80' }
              ]}
            >
              By Priority
            </Text>
          </TouchableOpacity>
        </View>
        
        <ScrollView
          style={styles.content}
          contentContainerStyle={styles.contentContainer}
        >
          <Animated.View entering={FadeIn.duration(400)}>
            {selectedTab === 'overview' && (
              <>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Task Status Overview</Text>
                {renderStatusPieChart()}
                <View style={styles.statsGrid}>
                  <StatsCard 
                    label="Completion Rate" 
                    value={totalTasks > 0 ? `${Math.round((completedCount / totalTasks) * 100)}%` : '0%'} 
                    textColor={colors.text}
                    valueColor={colors.success}
                  />
                  <StatsCard 
                    label="Delayed Rate" 
                    value={totalTasks > 0 ? `${Math.round((delayedCount / totalTasks) * 100)}%` : '0%'} 
                    textColor={colors.text}
                    valueColor={colors.error}
                  />
                  <StatsCard 
                    label="In Progress" 
                    value={totalTasks > 0 ? `${Math.round((inProgressCount / totalTasks) * 100)}%` : '0%'} 
                    textColor={colors.text}
                    valueColor={colors.warning}
                  />
                  <StatsCard 
                    label="Todo" 
                    value={totalTasks > 0 ? `${Math.round((todoCount / totalTasks) * 100)}%` : '0%'} 
                    textColor={colors.text}
                    valueColor={colors.primary}
                  />
                </View>
              </>
            )}
            
            {selectedTab === 'departments' && (
              <>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Department Performance</Text>
                {renderDepartmentStats()}
              </>
            )}
            
            {selectedTab === 'priority' && (
              <>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Tasks by Priority</Text>
                {renderPriorityStats()}
              </>
            )}
          </Animated.View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const StatsCard = ({ label, value, textColor, valueColor }: { label: string, value: string, textColor: string, valueColor: string }) => (
  <Animated.View 
    entering={FadeIn.duration(400)}
    style={[styles.statsCard]}
  >
    <Text style={[styles.statsCardValue, { color: valueColor }]}>{value}</Text>
    <Text style={[styles.statsCardLabel, { color: textColor + '80' }]}>{label}</Text>
  </Animated.View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabsContainer: {
    flexDirection: 'row',
    padding: Metrics.spacing.md,
    gap: Metrics.spacing.sm,
  },
  tabButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Metrics.spacing.sm,
    borderRadius: Metrics.borderRadius.md,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  activeTabButton: {
    borderWidth: 1,
  },
  tabButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.sm,
    marginLeft: Metrics.spacing.xs,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    padding: Metrics.spacing.lg,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.lg,
    marginBottom: Metrics.spacing.lg,
  },
  pieChartContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Metrics.spacing.xl,
  },
  emptyChartText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.lg,
  },
  legendContainer: {
    position: 'absolute',
    top: 0,
    right: 0,
    alignItems: 'flex-start',
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Metrics.spacing.xs,
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: Metrics.spacing.xs,
  },
  legendText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.sm,
  },
  pieChartCenter: {
    position: 'absolute',
    top: '40%',
    left: '40%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  totalTasks: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.xxxl,
  },
  totalTasksLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.sm,
  },
  segmentsContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  segment: {
    position: 'absolute',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: Metrics.spacing.md,
    marginBottom: Metrics.spacing.lg,
  },
  statsCard: {
    width: '48%',
    alignItems: 'center',
    padding: Metrics.spacing.md,
    marginBottom: Metrics.spacing.md,
  },
  statsCardValue: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.xxl,
    marginBottom: Metrics.spacing.xs,
  },
  statsCardLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.sm,
  },
  departmentStatsContainer: {
    marginBottom: Metrics.spacing.lg,
  },
  departmentCard: {
    padding: Metrics.spacing.md,
    borderRadius: Metrics.borderRadius.md,
    marginBottom: Metrics.spacing.md,
    borderWidth: 1,
  },
  departmentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Metrics.spacing.xs,
  },
  departmentColorIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: Metrics.spacing.xs,
  },
  departmentName: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.md,
  },
  taskCountText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.sm,
    marginBottom: Metrics.spacing.sm,
  },
  progressBarContainer: {
    width: '100%',
  },
  progressBar: {
    height: 8,
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.sm,
    marginTop: Metrics.spacing.xs,
    textAlign: 'right',
  },
  priorityContainer: {
    marginBottom: Metrics.spacing.lg,
  },
  priorityBarContainer: {
    marginBottom: Metrics.spacing.lg,
  },
  priorityLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Metrics.spacing.xs,
  },
  priorityIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: Metrics.spacing.xs,
  },
  priorityLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.md,
  },
  priorityBarWrapper: {
    marginBottom: Metrics.spacing.xs,
  },
  priorityBarBackground: {
    height: 24,
    borderRadius: Metrics.borderRadius.sm,
    overflow: 'hidden',
  },
  priorityBarFill: {
    height: '100%',
  },
  priorityCount: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.sm,
    textAlign: 'right',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Metrics.spacing.xxl,
  },
  emptyText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.lg,
  },
});