import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity,
  SafeAreaView
} from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import Metrics from '@/constants/Metrics';
import { Notification } from '@/types';
import { notifications } from '@/data/mockData';
import { useRouter } from 'expo-router';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { 
  Bell,
  Calendar,
  UserCheck,
  RefreshCw,
  Check,
  Clock
} from 'lucide-react-native';

export default function NotificationsScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  const [notifs, setNotifs] = useState<Notification[]>(notifications);
  
  const markAsRead = (id: string) => {
    setNotifs(prev => prev.map(notif => 
      notif.id === id ? { ...notif, isRead: true } : notif
    ));
  };
  
  const handleNotificationPress = (notification: Notification) => {
    markAsRead(notification.id);
    if (notification.taskId) {
      router.push(`/tasks/${notification.taskId}`);
    }
  };
  
  const markAllAsRead = () => {
    setNotifs(prev => prev.map(notif => ({ ...notif, isRead: true })));
  };
  
  const getIconForType = (type: string) => {
    switch (type) {
      case 'deadline':
        return <Calendar size={20} color={colors.error} />;
      case 'assignment':
        return <UserCheck size={20} color={colors.primary} />;
      case 'mention':
        return <Bell size={20} color={colors.accent} />;
      case 'update':
        return <RefreshCw size={20} color={colors.success} />;
      default:
        return <Bell size={20} color={colors.primary} />;
    }
  };
  
  const renderNotification = ({ item, index }: { item: Notification, index: number }) => (
    <Animated.View entering={FadeInDown.delay(index * 100).duration(400)}>
      <TouchableOpacity
        style={[
          styles.notificationItem, 
          { 
            backgroundColor: item.isRead ? colors.card : colors.primary + '10',
            borderColor: colors.border
          }
        ]}
        onPress={() => handleNotificationPress(item)}
      >
        <View style={styles.notificationIcon}>
          {getIconForType(item.type)}
        </View>
        <View style={styles.notificationContent}>
          <Text style={[styles.notificationTitle, { color: colors.text }]}>
            {item.title}
          </Text>
          <Text style={[styles.notificationMessage, { color: colors.text + '99' }]}>
            {item.message}
          </Text>
          <View style={styles.notificationFooter}>
            <View style={styles.timeContainer}>
              <Clock size={14} color={colors.text + '80'} />
              <Text style={[styles.notificationTime, { color: colors.text + '80' }]}>
                2 hours ago
              </Text>
            </View>
            {!item.isRead && (
              <View style={[styles.unreadIndicator, { backgroundColor: colors.primary }]} />
            )}
          </View>
        </View>
      </TouchableOpacity>
    </Animated.View>
  );
  
  const renderEmptyComponent = () => (
    <View style={styles.emptyContainer}>
      <Bell size={48} color={colors.text + '40'} />
      <Text style={[styles.emptyText, { color: colors.text + '80' }]}>
        No notifications yet
      </Text>
    </View>
  );
  
  const renderHeader = () => {
    const unreadCount = notifs.filter(n => !n.isRead).length;
    
    if (unreadCount === 0) return null;
    
    return (
      <View style={styles.headerContainer}>
        <Text style={[styles.headerText, { color: colors.text }]}>
          You have {unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}
        </Text>
        <TouchableOpacity
          style={[styles.markAllReadButton, { backgroundColor: colors.primary + '20' }]}
          onPress={markAllAsRead}
        >
          <Check size={16} color={colors.primary} />
          <Text style={[styles.markAllReadText, { color: colors.primary }]}>
            Mark all as read
          </Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlatList
        style={styles.container}
        contentContainerStyle={styles.contentContainer}
        data={notifs}
        keyExtractor={(item) => item.id}
        renderItem={renderNotification}
        ListEmptyComponent={renderEmptyComponent}
        ListHeaderComponent={renderHeader}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: Metrics.spacing.lg,
    paddingBottom: Metrics.spacing.xxl,
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Metrics.spacing.lg,
  },
  headerText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.md,
  },
  markAllReadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Metrics.spacing.md,
    paddingVertical: Metrics.spacing.xs,
    borderRadius: Metrics.borderRadius.sm,
  },
  markAllReadText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.sm,
    marginLeft: Metrics.spacing.xs,
  },
  notificationItem: {
    flexDirection: 'row',
    padding: Metrics.spacing.md,
    borderRadius: Metrics.borderRadius.md,
    marginBottom: Metrics.spacing.md,
    borderWidth: 1,
  },
  notificationIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: Metrics.spacing.md,
  },
  notificationContent: {
    flex: 1,
  },
  notificationTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.md,
    marginBottom: Metrics.spacing.xs,
  },
  notificationMessage: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
    marginBottom: Metrics.spacing.sm,
  },
  notificationFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  notificationTime: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.xs,
    marginLeft: Metrics.spacing.xs,
  },
  unreadIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Metrics.spacing.xxl,
  },
  emptyText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.lg,
    marginTop: Metrics.spacing.md,
  },
});