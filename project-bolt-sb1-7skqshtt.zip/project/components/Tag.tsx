import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { PriorityLevel, TaskStatus } from '@/types';
import Colors from '@/constants/Colors';
import Metrics from '@/constants/Metrics';
import { useColorScheme } from 'react-native';

interface TagProps {
  type: 'priority' | 'status' | 'department';
  value: PriorityLevel | TaskStatus | string;
  color?: string;
}

export function Tag({ type, value, color }: TagProps) {
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];

  const getBackground = () => {
    if (color) return color;
    
    if (type === 'priority') {
      switch (value) {
        case 'low': return colors.success;
        case 'medium': return colors.warning;
        case 'high': return colors.accent;
        case 'critical': return colors.error;
        default: return colors.primary;
      }
    } else if (type === 'status') {
      switch (value) {
        case 'todo': return colors.primary;
        case 'in_progress': return colors.warning;
        case 'completed': return colors.success;
        case 'delayed': return colors.error;
        default: return colors.primary;
      }
    }
    
    return colors.primary;
  };

  const getLabel = () => {
    if (type === 'priority') {
      switch (value) {
        case 'low': return 'Low';
        case 'medium': return 'Medium';
        case 'high': return 'High';
        case 'critical': return 'Critical';
        default: return value;
      }
    } else if (type === 'status') {
      switch (value) {
        case 'todo': return 'To Do';
        case 'in_progress': return 'In Progress';
        case 'completed': return 'Completed';
        case 'delayed': return 'Delayed';
        default: return value;
      }
    }
    
    return value;
  };

  return (
    <View style={[styles.container, { backgroundColor: getBackground() }]}>
      <Text style={styles.text}>{getLabel()}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: Metrics.spacing.sm,
    paddingVertical: Metrics.spacing.xs,
    borderRadius: Metrics.borderRadius.sm,
    alignSelf: 'flex-start',
  },
  text: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.xs,
    color: '#FFF',
  },
});