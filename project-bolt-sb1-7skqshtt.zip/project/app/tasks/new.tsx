import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView,
  TextInput,
  TouchableOpacity,
  SafeAreaView
} from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import Metrics from '@/constants/Metrics';
import { PriorityLevel } from '@/types';
import { departments, users } from '@/data/mockData';
import { useRouter, Stack } from 'expo-router';
import { 
  ArrowLeft, 
  Calendar, 
  User, 
  Building,
  ChevronDown,
  Flag
} from 'lucide-react-native';
import { Button } from '@/components/Button';

export default function CreateTaskScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const [taskForm, setTaskForm] = useState({
    title: '',
    description: '',
    dueDate: new Date().toISOString().split('T')[0],
    departmentId: '',
    assigneeId: '',
    priority: 'medium' as PriorityLevel,
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showDepartmentPicker, setShowDepartmentPicker] = useState(false);
  const [showAssigneePicker, setShowAssigneePicker] = useState(false);
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!taskForm.title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!taskForm.description.trim()) {
      newErrors.description = 'Description is required';
    }
    
    if (!taskForm.departmentId) {
      newErrors.departmentId = 'Department is required';
    }
    
    if (!taskForm.dueDate) {
      newErrors.dueDate = 'Due date is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleCreateTask = () => {
    if (validateForm()) {
      console.log('Creating task:', taskForm);
      // In a real app, this would save the task to the database
      router.back();
    }
  };
  
  const handleChange = (field: string, value: string) => {
    setTaskForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };
  
  const getSelectedDepartment = () => {
    if (!taskForm.departmentId) return 'Select Department';
    const dept = departments.find(d => d.id === taskForm.departmentId);
    return dept ? dept.name : 'Select Department';
  };
  
  const getSelectedAssignee = () => {
    if (!taskForm.assigneeId) return 'Select Assignee (Optional)';
    const user = users.find(u => u.id === taskForm.assigneeId);
    return user ? user.name : 'Select Assignee (Optional)';
  };
  
  const renderDepartmentPicker = () => {
    if (!showDepartmentPicker) return null;
    
    return (
      <View style={[styles.pickerContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {departments.map(dept => (
          <TouchableOpacity
            key={dept.id}
            style={[
              styles.pickerItem,
              { 
                borderBottomColor: colors.border,
                backgroundColor: taskForm.departmentId === dept.id ? colors.primary + '20' : 'transparent'
              }
            ]}
            onPress={() => {
              handleChange('departmentId', dept.id);
              setShowDepartmentPicker(false);
            }}
          >
            <View style={[styles.departmentColorDot, { backgroundColor: dept.color }]} />
            <Text style={[styles.pickerItemText, { color: colors.text }]}>{dept.name}</Text>
          </TouchableOpacity>
        ))}
      </View>
    );
  };
  
  const renderAssigneePicker = () => {
    if (!showAssigneePicker) return null;
    
    // Only show users from the selected department
    const filteredUsers = taskForm.departmentId
      ? users.filter(user => user.departmentId === taskForm.departmentId)
      : users;
    
    return (
      <View style={[styles.pickerContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <TouchableOpacity
          style={[
            styles.pickerItem,
            { 
              borderBottomColor: colors.border,
              backgroundColor: taskForm.assigneeId === '' ? colors.primary + '20' : 'transparent'
            }
          ]}
          onPress={() => {
            handleChange('assigneeId', '');
            setShowAssigneePicker(false);
          }}
        >
          <Text style={[styles.pickerItemText, { color: colors.text }]}>None</Text>
        </TouchableOpacity>
        
        {filteredUsers.map(user => (
          <TouchableOpacity
            key={user.id}
            style={[
              styles.pickerItem,
              { 
                borderBottomColor: colors.border,
                backgroundColor: taskForm.assigneeId === user.id ? colors.primary + '20' : 'transparent'
              }
            ]}
            onPress={() => {
              handleChange('assigneeId', user.id);
              setShowAssigneePicker(false);
            }}
          >
            <Text style={[styles.pickerItemText, { color: colors.text }]}>{user.name}</Text>
          </TouchableOpacity>
        ))}
      </View>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <Stack.Screen 
        options={{
          headerShown: true,
          headerTitle: 'Create New Task',
          headerLeft: () => (
            <TouchableOpacity onPress={() => router.back()}>
              <ArrowLeft size={24} color={colors.text} />
            </TouchableOpacity>
          ),
        }}
      />
      
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.contentContainer}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.formGroup}>
          <Text style={[styles.label, { color: colors.text }]}>Task Title</Text>
          <TextInput
            style={[
              styles.input,
              { 
                backgroundColor: colors.card, 
                borderColor: errors.title ? colors.error : colors.border,
                color: colors.text
              }
            ]}
            value={taskForm.title}
            onChangeText={(text) => handleChange('title', text)}
            placeholder="Enter task title"
            placeholderTextColor={colors.text + '60'}
          />
          {errors.title && (
            <Text style={[styles.errorText, { color: colors.error }]}>{errors.title}</Text>
          )}
        </View>
        
        <View style={styles.formGroup}>
          <Text style={[styles.label, { color: colors.text }]}>Description</Text>
          <TextInput
            style={[
              styles.textArea,
              { 
                backgroundColor: colors.card, 
                borderColor: errors.description ? colors.error : colors.border,
                color: colors.text
              }
            ]}
            value={taskForm.description}
            onChangeText={(text) => handleChange('description', text)}
            placeholder="Enter task description"
            placeholderTextColor={colors.text + '60'}
            multiline
            numberOfLines={4}
            textAlignVertical="top"
          />
          {errors.description && (
            <Text style={[styles.errorText, { color: colors.error }]}>{errors.description}</Text>
          )}
        </View>
        
        <View style={styles.formGroup}>
          <Text style={[styles.label, { color: colors.text }]}>Department</Text>
          <TouchableOpacity
            style={[
              styles.selectButton,
              { 
                backgroundColor: colors.card, 
                borderColor: errors.departmentId ? colors.error : colors.border
              }
            ]}
            onPress={() => {
              setShowDepartmentPicker(!showDepartmentPicker);
              setShowAssigneePicker(false);
            }}
          >
            <View style={styles.selectButtonContent}>
              <Building size={20} color={colors.primary} />
              <Text style={[styles.selectButtonText, { color: colors.text }]}>
                {getSelectedDepartment()}
              </Text>
            </View>
            <ChevronDown size={20} color={colors.text + '80'} />
          </TouchableOpacity>
          {renderDepartmentPicker()}
          {errors.departmentId && (
            <Text style={[styles.errorText, { color: colors.error }]}>{errors.departmentId}</Text>
          )}
        </View>
        
        <View style={styles.formGroup}>
          <Text style={[styles.label, { color: colors.text }]}>Assignee</Text>
          <TouchableOpacity
            style={[
              styles.selectButton,
              { 
                backgroundColor: colors.card, 
                borderColor: errors.assigneeId ? colors.error : colors.border
              }
            ]}
            onPress={() => {
              setShowAssigneePicker(!showAssigneePicker);
              setShowDepartmentPicker(false);
            }}
            disabled={!taskForm.departmentId}
          >
            <View style={styles.selectButtonContent}>
              <User size={20} color={colors.primary} />
              <Text style={[styles.selectButtonText, { color: colors.text }]}>
                {getSelectedAssignee()}
              </Text>
            </View>
            <ChevronDown size={20} color={colors.text + '80'} />
          </TouchableOpacity>
          {renderAssigneePicker()}
          {!taskForm.departmentId && (
            <Text style={[styles.helperText, { color: colors.text + '80' }]}>
              Select a department first
            </Text>
          )}
        </View>
        
        <View style={styles.formGroup}>
          <Text style={[styles.label, { color: colors.text }]}>Due Date</Text>
          <TouchableOpacity
            style={[
              styles.selectButton,
              { 
                backgroundColor: colors.card, 
                borderColor: errors.dueDate ? colors.error : colors.border
              }
            ]}
          >
            <View style={styles.selectButtonContent}>
              <Calendar size={20} color={colors.primary} />
              <Text style={[styles.selectButtonText, { color: colors.text }]}>
                {taskForm.dueDate || 'Select Due Date'}
              </Text>
            </View>
            <ChevronDown size={20} color={colors.text + '80'} />
          </TouchableOpacity>
          {errors.dueDate && (
            <Text style={[styles.errorText, { color: colors.error }]}>{errors.dueDate}</Text>
          )}
        </View>
        
        <View style={styles.formGroup}>
          <Text style={[styles.label, { color: colors.text }]}>Priority</Text>
          <View style={styles.priorityContainer}>
            {(['low', 'medium', 'high', 'critical'] as PriorityLevel[]).map((priority) => (
              <TouchableOpacity
                key={priority}
                style={[
                  styles.priorityButton,
                  { 
                    backgroundColor: 
                      taskForm.priority === priority 
                        ? getPriorityColor(priority, colors)
                        : colors.card,
                    borderColor: taskForm.priority === priority 
                      ? getPriorityColor(priority, colors)
                      : colors.border
                  }
                ]}
                onPress={() => handleChange('priority', priority)}
              >
                <Flag size={16} color={taskForm.priority === priority ? '#FFF' : getPriorityColor(priority, colors)} />
                <Text 
                  style={[
                    styles.priorityButtonText, 
                    { 
                      color: taskForm.priority === priority 
                        ? '#FFF' 
                        : colors.text 
                    }
                  ]}
                >
                  {priority.charAt(0).toUpperCase() + priority.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        
        <View style={styles.actions}>
          <Button
            title="Cancel"
            onPress={() => router.back()}
            variant="outline"
            style={{ flex: 1, marginRight: Metrics.spacing.md }}
          />
          <Button
            title="Create Task"
            onPress={handleCreateTask}
            variant="primary"
            style={{ flex: 1 }}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const getPriorityColor = (priority: PriorityLevel, colors: any) => {
  switch (priority) {
    case 'low': return colors.success;
    case 'medium': return colors.warning;
    case 'high': return colors.accent;
    case 'critical': return colors.error;
    default: return colors.primary;
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: Metrics.spacing.lg,
  },
  formGroup: {
    marginBottom: Metrics.spacing.lg,
  },
  label: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.md,
    marginBottom: Metrics.spacing.sm,
  },
  input: {
    borderWidth: 1,
    borderRadius: Metrics.borderRadius.md,
    paddingHorizontal: Metrics.spacing.md,
    paddingVertical: Metrics.spacing.sm,
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
  },
  textArea: {
    borderWidth: 1,
    borderRadius: Metrics.borderRadius.md,
    paddingHorizontal: Metrics.spacing.md,
    paddingVertical: Metrics.spacing.sm,
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
    minHeight: 100,
  },
  selectButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: Metrics.borderRadius.md,
    paddingHorizontal: Metrics.spacing.md,
    paddingVertical: Metrics.spacing.sm,
  },
  selectButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectButtonText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
    marginLeft: Metrics.spacing.sm,
  },
  pickerContainer: {
    borderWidth: 1,
    borderRadius: Metrics.borderRadius.md,
    marginTop: Metrics.spacing.xs,
    maxHeight: 200,
  },
  pickerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Metrics.spacing.md,
    paddingVertical: Metrics.spacing.md,
    borderBottomWidth: 1,
  },
  pickerItemText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
  },
  departmentColorDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: Metrics.spacing.sm,
  },
  priorityContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  priorityButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Metrics.spacing.sm,
    borderWidth: 1,
    borderRadius: Metrics.borderRadius.md,
    marginHorizontal: 2,
  },
  priorityButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.sm,
    marginLeft: Metrics.spacing.xs,
  },
  errorText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.sm,
    marginTop: Metrics.spacing.xs,
  },
  helperText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.sm,
    marginTop: Metrics.spacing.xs,
    fontStyle: 'italic',
  },
  actions: {
    flexDirection: 'row',
    marginTop: Metrics.spacing.md,
    marginBottom: Metrics.spacing.xl,
  },
});