export function formatDate(date: Date): string {
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function formatDistanceToNow(date: Date): string {
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  const diffInDays = Math.floor(diffInSeconds / 86400);
  const diffInHours = Math.floor(diffInSeconds / 3600) % 24;
  const diffInMinutes = Math.floor(diffInSeconds / 60) % 60;
  
  if (date > now) {
    // Future date
    const diffInSeconds = Math.floor((date.getTime() - now.getTime()) / 1000);
    const diffInDays = Math.floor(diffInSeconds / 86400);
    const diffInHours = Math.floor(diffInSeconds / 3600) % 24;
    const diffInMinutes = Math.floor(diffInSeconds / 60) % 60;
    
    if (diffInDays > 0) {
      return `in ${diffInDays} day${diffInDays === 1 ? '' : 's'}`;
    }
    if (diffInHours > 0) {
      return `in ${diffInHours} hour${diffInHours === 1 ? '' : 's'}`;
    }
    if (diffInMinutes > 0) {
      return `in ${diffInMinutes} minute${diffInMinutes === 1 ? '' : 's'}`;
    }
    return 'just now';
  }
  
  // Past date
  if (diffInDays > 0) {
    return `${diffInDays} day${diffInDays === 1 ? '' : 's'} ago`;
  }
  if (diffInHours > 0) {
    return `${diffInHours} hour${diffInHours === 1 ? '' : 's'} ago`;
  }
  if (diffInMinutes > 0) {
    return `${diffInMinutes} minute${diffInMinutes === 1 ? '' : 's'} ago`;
  }
  return 'just now';
}

export function formatDueDate(date: Date): string {
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  if (date.toDateString() === now.toDateString()) {
    return 'Today';
  }
  if (date.toDateString() === tomorrow.toDateString()) {
    return 'Tomorrow';
  }
  
  return formatDate(date);
}

export function isOverdue(dueDate: string, status: string): boolean {
  return new Date(dueDate) < new Date() && status !== 'completed';
}