import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Switch,
  TouchableOpacity,
  SafeAreaView,
  ScrollView
} from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import Metrics from '@/constants/Metrics';
import { Bell, Moon, User, Shield, Building2, LogOut, ChevronRight, CircleHelp as HelpCircle, Languages } from 'lucide-react-native';

export default function SettingsScreen() {
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const [notificationSettings, setNotificationSettings] = useState({
    taskAssignments: true,
    taskUpdates: true,
    approachingDeadlines: true,
    mentions: true,
  });
  
  const toggleSwitch = (setting: keyof typeof notificationSettings) => {
    setNotificationSettings(prev => ({
      ...prev,
      [setting]: !prev[setting]
    }));
  };
  
  const SettingSection = ({ title, children }: { title: string, children: React.ReactNode }) => (
    <View style={styles.section}>
      <Text style={[styles.sectionTitle, { color: colors.text + '99' }]}>{title}</Text>
      {children}
    </View>
  );
  
  const SwitchItem = ({ 
    label, 
    value, 
    onToggle 
  }: { 
    label: string, 
    value: boolean, 
    onToggle: () => void 
  }) => (
    <View style={[styles.settingItem, { borderBottomColor: colors.border }]}>
      <Text style={[styles.settingLabel, { color: colors.text }]}>{label}</Text>
      <Switch
        trackColor={{ false: colors.border, true: colors.primary + '80' }}
        thumbColor={value ? colors.primary : colors.tabIconDefault}
        ios_backgroundColor={colors.border}
        onValueChange={onToggle}
        value={value}
      />
    </View>
  );
  
  const NavigationItem = ({ 
    label, 
    icon, 
    onPress 
  }: { 
    label: string, 
    icon: React.ReactNode, 
    onPress: () => void 
  }) => (
    <TouchableOpacity 
      style={[styles.navigationItem, { borderBottomColor: colors.border }]}
      onPress={onPress}
    >
      <View style={styles.navigationLabel}>
        {icon}
        <Text style={[styles.navigationText, { color: colors.text }]}>{label}</Text>
      </View>
      <ChevronRight size={20} color={colors.text + '80'} />
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.contentContainer}
      >
        <SettingSection title="Account">
          <NavigationItem
            label="Profile Settings"
            icon={<User size={20} color={colors.primary} />}
            onPress={() => {}}
          />
          <NavigationItem
            label="Department Management"
            icon={<Building2 size={20} color={colors.secondary} />}
            onPress={() => {}}
          />
          <NavigationItem
            label="Security"
            icon={<Shield size={20} color={colors.accent} />}
            onPress={() => {}}
          />
        </SettingSection>
        
        <SettingSection title="Notifications">
          <SwitchItem
            label="Task Assignments"
            value={notificationSettings.taskAssignments}
            onToggle={() => toggleSwitch('taskAssignments')}
          />
          <SwitchItem
            label="Task Updates"
            value={notificationSettings.taskUpdates}
            onToggle={() => toggleSwitch('taskUpdates')}
          />
          <SwitchItem
            label="Approaching Deadlines"
            value={notificationSettings.approachingDeadlines}
            onToggle={() => toggleSwitch('approachingDeadlines')}
          />
          <SwitchItem
            label="Mentions"
            value={notificationSettings.mentions}
            onToggle={() => toggleSwitch('mentions')}
          />
        </SettingSection>
        
        <SettingSection title="Appearance">
          <View style={[styles.settingItem, { borderBottomColor: colors.border }]}>
            <View style={styles.navigationLabel}>
              <Moon size={20} color={colors.text} />
              <Text style={[styles.settingLabel, { color: colors.text }]}>Dark Mode</Text>
            </View>
            <Text style={[styles.settingValueText, { color: colors.text + '80' }]}>
              System
            </Text>
          </View>
          <NavigationItem
            label="Language"
            icon={<Languages size={20} color={colors.text} />}
            onPress={() => {}}
          />
        </SettingSection>
        
        <SettingSection title="Support">
          <NavigationItem
            label="Help & FAQ"
            icon={<HelpCircle size={20} color={colors.primary} />}
            onPress={() => {}}
          />
          <NavigationItem
            label="Contact Support"
            icon={<Bell size={20} color={colors.primary} />}
            onPress={() => {}}
          />
        </SettingSection>
        
        <TouchableOpacity 
          style={[styles.logoutButton, { backgroundColor: colors.error + '10' }]}
          onPress={() => {}}
        >
          <LogOut size={20} color={colors.error} />
          <Text style={[styles.logoutText, { color: colors.error }]}>Sign Out</Text>
        </TouchableOpacity>
        
        <Text style={[styles.versionText, { color: colors.text + '60' }]}>
          Version 1.0.0
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: Metrics.spacing.lg,
  },
  section: {
    marginBottom: Metrics.spacing.xl,
  },
  sectionTitle: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.sm,
    marginBottom: Metrics.spacing.md,
    textTransform: 'uppercase',
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Metrics.spacing.md,
    borderBottomWidth: 1,
  },
  settingLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.md,
  },
  settingValueText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
  },
  navigationItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Metrics.spacing.md,
    borderBottomWidth: 1,
  },
  navigationLabel: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  navigationText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.md,
    marginLeft: Metrics.spacing.md,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Metrics.spacing.md,
    borderRadius: Metrics.borderRadius.md,
    marginBottom: Metrics.spacing.xl,
  },
  logoutText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.md,
    marginLeft: Metrics.spacing.sm,
  },
  versionText: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.sm,
    textAlign: 'center',
    marginBottom: Metrics.spacing.lg,
  },
});