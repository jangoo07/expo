import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  RefreshControl,
  TouchableOpacity,
  SafeAreaView 
} from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import Metrics from '@/constants/Metrics';
import { StatusCard } from '@/components/StatusCard';
import { TaskCard } from '@/components/TaskCard';
import { Task } from '@/types';
import { getTaskStats, tasks } from '@/data/mockData';
import { useRouter } from 'expo-router';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { ArrowUpRight, Clock, CircleAlert as AlertCircle } from 'lucide-react-native';

export default function DashboardScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  const [refreshing, setRefreshing] = useState(false);
  
  const { todoCount, inProgressCount, completedCount, delayedCount } = getTaskStats();
  
  // Find upcoming deadlines (tasks due in the next 48 hours)
  const now = new Date();
  const twoDaysFromNow = new Date(now);
  twoDaysFromNow.setHours(now.getHours() + 48);
  
  const upcomingDeadlines = tasks
    .filter(task => {
      const dueDate = new Date(task.dueDate);
      return dueDate > now && dueDate <= twoDaysFromNow && task.status !== 'completed';
    })
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
  
  // Find delayed tasks
  const delayedTasks = tasks
    .filter(task => task.status === 'delayed')
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());

  const handleTaskPress = (task: Task) => {
    // Navigate to task details
    router.push(`/tasks/${task.id}`);
  };
  
  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    // Simulate loading
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  }, []);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.contentContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <Animated.View entering={FadeIn.duration(400)}>
          <Text style={[styles.greeting, { color: colors.text }]}>
            Hello, John 👋
          </Text>
          <Text style={[styles.subtitle, { color: colors.text + '99' }]}>
            Here's your task overview
          </Text>
        </Animated.View>
        
        <Animated.View 
          entering={FadeInDown.delay(200).duration(400)}
          style={styles.statsContainer}
        >
          <View style={styles.row}>
            <StatusCard
              title="To Do"
              count={todoCount}
              type="todo"
              index={0}
            />
            <StatusCard
              title="In Progress"
              count={inProgressCount}
              type="in_progress"
              index={1}
            />
          </View>
          <View style={styles.row}>
            <StatusCard
              title="Completed"
              count={completedCount}
              type="completed"
              index={2}
            />
            <StatusCard
              title="Delayed"
              count={delayedCount}
              type="delayed"
              index={3}
            />
          </View>
        </Animated.View>
        
        {upcomingDeadlines.length > 0 && (
          <Animated.View entering={FadeInDown.delay(400).duration(400)}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionTitleContainer}>
                <Clock size={20} color={colors.warning} />
                <Text style={[styles.sectionTitle, { color: colors.text }]}>
                  Upcoming Deadlines
                </Text>
              </View>
              <TouchableOpacity 
                onPress={() => router.push('/tasks?filter=upcoming')}
                style={styles.viewAllButton}
              >
                <Text style={[styles.viewAllText, { color: colors.primary }]}>
                  View All
                </Text>
                <ArrowUpRight size={16} color={colors.primary} />
              </TouchableOpacity>
            </View>
            
            {upcomingDeadlines.slice(0, 2).map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                onPress={handleTaskPress}
              />
            ))}
          </Animated.View>
        )}
        
        {delayedTasks.length > 0 && (
          <Animated.View entering={FadeInDown.delay(600).duration(400)}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionTitleContainer}>
                <AlertCircle size={20} color={colors.error} />
                <Text style={[styles.sectionTitle, { color: colors.text }]}>
                  Delayed Tasks
                </Text>
              </View>
              <TouchableOpacity 
                onPress={() => router.push('/tasks?filter=delayed')}
                style={styles.viewAllButton}
              >
                <Text style={[styles.viewAllText, { color: colors.primary }]}>
                  View All
                </Text>
                <ArrowUpRight size={16} color={colors.primary} />
              </TouchableOpacity>
            </View>
            
            {delayedTasks.slice(0, 2).map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                onPress={handleTaskPress}
              />
            ))}
          </Animated.View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: Metrics.spacing.lg,
  },
  greeting: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.xxl,
    marginBottom: Metrics.spacing.xs,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: Metrics.fontSize.md,
    marginBottom: Metrics.spacing.xl,
  },
  statsContainer: {
    marginBottom: Metrics.spacing.xl,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: Metrics.spacing.md,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Metrics.spacing.md,
  },
  sectionTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: Metrics.fontSize.lg,
    marginLeft: Metrics.spacing.xs,
  },
  viewAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  viewAllText: {
    fontFamily: 'Inter-Medium',
    fontSize: Metrics.fontSize.sm,
    marginRight: Metrics.spacing.xs,
  },
});